package midiSynthesizer;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import javax.swing.JFrame;
import javax.swing.JTextField;
public class qwertySynth {		
	private static int octave=60;
	private static int velocity=100;
	private static int time = 10;
	private static Note currentNote;
	private static boolean sustain= false;

	public static void main(String[] argv) throws Exception {
		JTextField textField = new JTextField();
		textField.addKeyListener(new MKeyListener());
		JFrame jframe = new JFrame();
		jframe.add(textField);
		jframe.setSize(400, 350);
		jframe.setVisible(true);
	}

	public static int getOctave() {
		return octave;
	}

	public static void setOctave(int octave) {
		qwertySynth.octave = octave;
	}

	public static int getVelocity() {
		return velocity;
	}

	public static void setVelocity(int velocity) {
		qwertySynth.velocity = velocity;
	}

	public static int getTime() {
		return time;
	}

	public static void setTime(int time) {
		qwertySynth.time = time;
	}

	public static Note getCurrentNote() {
		return currentNote;
	}

	public static void setCurrentNote(Note currentNote) {
		qwertySynth.currentNote = currentNote;
	}

	public static boolean getSustain() {
		return sustain;
	}

	public static void setSustain(boolean sustain) {
		qwertySynth.sustain = sustain;
	}
}
class MKeyListener extends KeyAdapter {
	@Override

	public void keyPressed(KeyEvent event) {
		char ch = event.getKeyChar();
		int octave = qwertySynth.getOctave();
		int velocity = qwertySynth.getVelocity();
		int time=qwertySynth.getTime();
		boolean play=false;
		char[] keyboardNotes = {'a','s','d','f','g','h','j','k','l', ';','\'','w','e','r','t','y','u','i','o','p','[',']'};
		String[] notes = {"C-","D-","E-","F-","G-","A-","B-","C-","D-","E-","F-","C#","D#","E#","F#","G#","A#","B#","C#","D#","E#","F#"};
		int index = 0;
		try{
			index = Song.indexOf(keyboardNotes, ch);//finds index of the key pressed
			if (index>6&&index<11||index>17){
				octave+=12;
			}
			play=true;
		} catch (Exception e){
			otherFunctions(ch, octave, time, velocity);	
		}
		if (play){
			char noteName=notes[index].charAt(0);//assign note value based on index of key pressed
			char sign = notes[index].charAt(1);
			Note note = new Note(noteName, sign, octave);
			qwertySynth.setCurrentNote(note);
			if(!qwertySynth.getSustain()){
			Synth.play(note.getNoteValue(), time, velocity);
			}else{
			Synth.start(note.getNoteValue(), velocity);
			}
			qwertySynth.setSustain(false);
			/*if (qwertySynth.getSustain()){
				try { Thread.sleep(1000); // wait time in milliseconds to control duration
				} catch( InterruptedException e ) { System.out.println("ahhahhhaha");}
			} else if(qwertySynth.getCurrentNote()!=note) {
				System.out.println("note end");
				Synth.end(note.getNoteValue());
			}*/

		}
	}

	private void otherFunctions(char ch, int octave, int time, int velocity) {
		if (ch=='z'){
			qwertySynth.setOctave(octave-12);;
		}
		if (ch=='x'){
			qwertySynth.setOctave(octave+12);;
		}	
		if (ch=='.'){
			qwertySynth.setTime(time+10);
		}
		if (ch==','){
			qwertySynth.setTime(time-10);
		}
		if (ch==' '){
			qwertySynth.setSustain(true);
		}
		if (ch=='c'){
			qwertySynth.setVelocity(velocity-10);
		}
		if (ch=='v'){
			qwertySynth.setVelocity(velocity+10);
		}

	}

	static int indexOf(String[] notes, String c) throws IllegalArgumentException {
		for (int i=0; i<=notes.length-1; i++){
			if (notes[i]==(c)){
				return i;
			}
		}
		throw new IllegalArgumentException();
	}
}

