package midiSynthesizer;

import javax.sound.midi.Instrument;
import javax.sound.midi.MidiChannel;
import javax.sound.midi.MidiSystem;
import javax.sound.midi.MidiUnavailableException;
import javax.sound.midi.Synthesizer;

public class Synth {
	private static MidiChannel[] mChannels;
	private static Instrument[] instr;
	private static int note;
	//private static int velocity = 100;
	public Synth(Note n){
		note=n.getNoteValue();
	}
	public static void play(int note, int time, int velocity){
		try{

			Synthesizer midiSynth = MidiSystem.getSynthesizer(); 
			midiSynth.open();
			//get and load default instrument and channel lists
			instr = midiSynth.getDefaultSoundbank().getInstruments();
			int n = 0;
			for (Instrument i:instr){
				n++;
				System.out.println(n + " "+i.getPatch());
			}
			
			mChannels = midiSynth.getChannels();
			//midiSynth.loadInstrument(instr[36]);//load an instrument
			Instrument[] loadInstr = midiSynth.getLoadedInstruments();
			for(Instrument i: loadInstr){
				midiSynth.unloadInstrument(i);
			}
			
			midiSynth.loadInstrument(instr[0]);
			mChannels[0].noteOn(note, velocity);//On channel 4, play note i with velocity
			try { Thread.sleep(time); // wait time in milliseconds to control duration
			} catch( InterruptedException e ) { }
			mChannels[0].noteOff(note);//turn of the note
		} catch (MidiUnavailableException e) {}
	
	}
	public static void start(int note, int velocity) {
		try{
			Synthesizer midiSynth = MidiSystem.getSynthesizer(); 
		midiSynth.open();
		instr = midiSynth.getDefaultSoundbank().getInstruments();
		mChannels = midiSynth.getChannels();
		midiSynth.loadInstrument(instr[0]);
		mChannels[0].noteOn(note, velocity);//On channel 4, play note i with velocity
		} catch(Exception e){
			System.out.println("aaaahhhh in no work");
		}
	}
	
	public static void end(int note){
		mChannels[0].noteOff(note);//turn of the note
		System.out.println("note off");

	}


}
